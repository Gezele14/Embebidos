#ifndef _MATHC_H
#define _MATHC_H

float add(float num1, float num2);
float sub(float num1, float num2);
float mul(float num1, float num2);
float div(float num1, float num2);
float raiz(float num1);

#endif